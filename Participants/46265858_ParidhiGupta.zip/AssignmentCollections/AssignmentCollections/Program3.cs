﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentCollections
{
    internal class Program3
    {
        static void Main()
        {
            SortedList list = new SortedList();
            Console.WriteLine("Enter number of employees");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            for(int i = 0; i < num; i++)
            {
                Console.WriteLine("Enter employee code");
                int code = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter employee name");
                string name = Console.ReadLine();
                list.Add(code, name);
            }
            Console.WriteLine("");
            foreach (var k in list.Keys)
            {
                Console.WriteLine($"Employee Code: {k}, Employee Name: {list[k]}");
            }
        }
    }
}
