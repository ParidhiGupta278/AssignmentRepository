﻿using System.Collections;
using System.ComponentModel;

namespace AssignmentCollections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();
            Console.WriteLine("Enter 10 numbers");
            for(int i= 0; i < 9; i++)
            {
                list.Add(Console.ReadLine());
            }
            list.Sort();
            foreach(var i in list)
            {
                Console.WriteLine(i);
            }
        }
    }
}