﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentCollections
{
    internal class Student
    {
        public int sid { get; set; }
        public string sname { get; set; }
        public int std { get; set; }
    }

    class Program5
    {
        static void Main()
        {
            Student student = new Student();
            Console.WriteLine("Enter number of students");
            int num = int.Parse(Console.ReadLine());
            ArrayList list = new ArrayList(num);
            for (int i = 0; i < num; i++)
            {
                Console.WriteLine("Enter Student ID");
                student.sid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Student Name");
                student.sname = Console.ReadLine();
                Console.WriteLine("Enter Student Std");
                student.std = int.Parse(Console.ReadLine());
                list.Add(student);
            }
            Console.WriteLine("");
            foreach (Student s in list)
            {
                Console.WriteLine($"Student ID: {s.sid}, Student Name: {s.sname}, Student Std: {s.std}");
            }
        }
    }
}
