﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentCollections
{
    internal class BookStore
    {
        static void Main()
        {
            Hashtable list = new Hashtable();
            Console.WriteLine("Enter number of books");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            for (int i = 0; i < num; i++)
            {
                Console.WriteLine("Enter Book ID");
                int code = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Book Name");
                string name = Console.ReadLine();
                list.Add(code, name);
            }
            Console.WriteLine("");
            foreach (var k in list.Keys)
            {
                Console.WriteLine($"Book ID: {k}, Book Name: {list[k]}");
            }
        }
    }
}
