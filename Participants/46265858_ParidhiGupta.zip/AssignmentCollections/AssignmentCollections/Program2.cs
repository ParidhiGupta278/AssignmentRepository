﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentCollections
{
    internal class Program2
    {
        static void Main()
        {
            Console.WriteLine("Enter number of students");
            int num = int.Parse(Console.ReadLine());
            ArrayList list = new ArrayList(num);
            Console.WriteLine("Enter student names");
            for (int i = 0; i < num; i++)
            {
                list.Add(Console.ReadLine());
            }
            list.Sort();
            list.Reverse();
            foreach (var i in list)
            {
                Console.WriteLine(i);
            }
        }
    }
}
