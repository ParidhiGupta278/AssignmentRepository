﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentCollections
{
    
    class Employee
    {
        public string name { get; set; }
        public string desg { get; set; }
    }
    internal class Program6
    {
        static void Main()
        {
            ArrayList list = new ArrayList();
            Console.WriteLine("Enter number of employees");
            int num = int.Parse(Console.ReadLine());
            for(int i = 0; i < num; i++)
            {
                Employee employee = new Employee();
                Console.WriteLine("Enter Employee Name");
                employee.name = Console.ReadLine();
                Console.WriteLine("Enter Employee Designation");
                employee.desg = Console.ReadLine();
                list.Add(employee);
            }
            Console.WriteLine("");
            ArrayList desg = new ArrayList() { "Program Manager", "Project Manager", "Team  Lead", "Senior Programmer", "Junior Programmer" };
            foreach (string a in desg)
            {
                foreach (Employee emp in list)
                {
                    if (a == Convert.ToString(emp.desg))
                    {
                        Console.WriteLine($"Employee Name: {emp.name}, Employee Designation: {emp.desg}");
                    }
                    else
                    {
                        continue;
                    }
            }
            }
            
        }
    }
}
